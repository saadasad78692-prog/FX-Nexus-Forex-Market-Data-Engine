import sqlite3
import os
import re
from pathlib import Path

# Set up paths
PROJECT_DIR = Path(r'C:\Users\ASAD SAAD\Desktop\S4\DATABASE\project\milestone3\files')
DDL_DIR = PROJECT_DIR / "ddl"
DB_DIR = PROJECT_DIR / "db"
DB_PATH = DB_DIR / "fx_nexus.db"

def setup_database():
    """Create and populate the FX Nexus database"""
    
    # Create directories if they don't exist
    DDL_DIR.mkdir(exist_ok=True)
    DB_DIR.mkdir(exist_ok=True)
    
    # Remove existing database if it exists
    if DB_PATH.exists():
        DB_PATH.unlink()
        print(f"✓ Removed existing database")
    
    # Connect to new database
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Enable foreign keys
    cursor.execute("PRAGMA foreign_keys = ON;")
    
    print("="*60)
    print("FX NEXUS DATABASE SETUP")
    print("="*60)
    
    # Step 1: Execute the SQLite DDL
    ddl_file = DDL_DIR / "fx_nexus_sqlite.sql"
    
    if not ddl_file.exists():
        print(f"\n❌ Error: {ddl_file} not found!")
        print("Please create fx_nexus_sqlite.sql in the ddl folder")
        conn.close()
        return False
    
    print(f"\n📄 Reading DDL from: {ddl_file.name}")
    
    with open(ddl_file, 'r', encoding='utf-8') as f:
        ddl_content = f.read()
    
    # Execute the DDL
    try:
        cursor.executescript(ddl_content)
        print("✓ Schema created successfully")
    except Exception as e:
        print(f"❌ Error creating schema: {e}")
        conn.close()
        return False
    
    # Step 2: Insert sample data (dbDML.sql converted)
    print("\n📊 Inserting sample data...")
    
    # Insert currency pairs
    currency_pairs = [
        ('EUR', 'USD', 'EUR/USD', 0.00010, 1),
        ('GBP', 'USD', 'GBP/USD', 0.00010, 1),
        ('USD', 'JPY', 'USD/JPY', 0.01000, 1),
        ('USD', 'CHF', 'USD/CHF', 0.00010, 1),
        ('AUD', 'USD', 'AUD/USD', 0.00010, 1),
        ('NZD', 'USD', 'NZD/USD', 0.00010, 1),
        ('USD', 'CAD', 'USD/CAD', 0.00010, 1),
        ('EUR', 'GBP', 'EUR/GBP', 0.00010, 1),
        ('EUR', 'JPY', 'EUR/JPY', 0.01000, 1),
        ('GBP', 'JPY', 'GBP/JPY', 0.01000, 1),
        ('AUD', 'JPY', 'AUD/JPY', 0.01000, 1),
        ('EUR', 'CHF', 'EUR/CHF', 0.00010, 1),
        ('GBP', 'CHF', 'GBP/CHF', 0.00010, 1),
        ('EUR', 'AUD', 'EUR/AUD', 0.00010, 1),
        ('EUR', 'CAD', 'EUR/CAD', 0.00010, 1),
        ('AUD', 'CAD', 'AUD/CAD', 0.00010, 0),
        ('NZD', 'JPY', 'NZD/JPY', 0.01000, 0),
        ('USD', 'SGD', 'USD/SGD', 0.00010, 1),
        ('USD', 'HKD', 'USD/HKD', 0.00010, 0),
        ('XAU', 'USD', 'XAU/USD', 0.01000, 1)
    ]
    
    cursor.executemany("""
        INSERT INTO currency_pair (base_currency, quote_currency, pair_symbol, pip_value, is_active)
        VALUES (?, ?, ?, ?, ?)
    """, currency_pairs)
    print(f"  ✓ Inserted {len(currency_pairs)} currency pairs")
    
    # Insert data sources
    data_sources = [
        ('Yahoo Finance', 'API', 'https://query1.finance.yahoo.com/v8/finance', None, '2026-06-01 12:00:00', 1),
        ('OANDA API', 'API', 'https://api-fxtrade.oanda.com/v3', 'oanda-key-xxxx-1234', '2026-06-10 08:00:00', 1),
        ('MetaTrader 5 Export', 'PlatformExport', None, None, '2026-05-15 17:30:00', 1),
        ('Alpha Vantage', 'API', 'https://www.alphavantage.co/query', 'av-key-yyyy-5678', '2026-06-09 06:00:00', 1),
        ('Polygon.io API', 'API', 'https://api.polygon.io/v2/aggs', 'poly-key-zzzz-9012', '2026-06-10 07:00:00', 1)
    ]
    
    cursor.executemany("""
        INSERT INTO data_source (source_name, source_type, base_url, api_key, last_sync_time, is_active)
        VALUES (?, ?, ?, ?, ?, ?)
    """, data_sources)
    print(f"  ✓ Inserted {len(data_sources)} data sources")
    
    # Insert traders
    traders = [
        ('Saad Nawaz', 'saad.nawaz@namal.edu.pk', 'hash_saad_001', 'Strategy'),
        ('Ali Hassan', 'ali.hassan@namal.edu.pk', 'hash_ali_002', 'Analyst'),
        ('Fatima Malik', 'fatima.malik@namal.edu.pk', 'hash_fatima_003', 'Strategy'),
        ('Omar Farooq', 'omar.farooq@gmail.com', 'hash_omar_004', 'Analyst'),
        ('Zara Ahmed', 'zara.ahmed@gmail.com', 'hash_zara_005', 'Strategy')
    ]
    
    cursor.executemany("""
        INSERT INTO trader (full_name, email, password_hash, trader_type)
        VALUES (?, ?, ?, ?)
    """, traders)
    print(f"  ✓ Inserted {len(traders)} traders")
    
    # Insert analyst traders
    analyst_traders = [(2, 'RSI,MA,MACD', 2000), (4, 'BollingerBand,RSI', 1500)]
    cursor.executemany("""
        INSERT INTO analyst_trader (trader_id, preferred_indicators, query_history_limit)
        VALUES (?, ?, ?)
    """, analyst_traders)
    
    # Insert strategy traders
    strategy_traders = [(1, 'Medium', 0.10, 20.00), (3, 'Low', 0.01, 10.00), (5, 'High', 0.50, 35.00)]
    cursor.executemany("""
        INSERT INTO strategy_trader (trader_id, risk_tolerance, default_lot_size, max_drawdown_pct)
        VALUES (?, ?, ?, ?)
    """, strategy_traders)
    
    # Insert sample price bars
    price_bars = [
        (1, 1, 'H1', '2026-06-01 00:00:00', 1.08450, 1.08710, 1.08320, 1.08600, 18452),
        (1, 1, 'H1', '2026-06-01 01:00:00', 1.08600, 1.08750, 1.08500, 1.08680, 14320),
        (1, 1, 'H1', '2026-06-01 02:00:00', 1.08680, 1.08820, 1.08610, 1.08790, 11250),
        (1, 1, 'H1', '2026-06-01 03:00:00', 1.08790, 1.08900, 1.08650, 1.08710, 9870),
        (1, 1, 'H1', '2026-06-01 04:00:00', 1.08710, 1.08760, 1.08480, 1.08520, 8210)
    ]
    
    cursor.executemany("""
        INSERT INTO price_bar (pair_id, source_id, timeframe, open_time, open_price, high_price, low_price, close_price, volume)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, price_bars)
    print(f"  ✓ Inserted {len(price_bars)} price bars")
    
    # Insert sample strategies
    strategies = [
        (1, 'MA Crossover 20/50', 'MA(20) crosses above MA(50)', 'MA(20) crosses below MA(50)', '{"fast":20,"slow":50}', 1),
        (1, 'RSI Reversal 30/70', 'RSI(14) drops below 30', 'RSI(14) rises above 70', '{"period":14,"ob":70,"os":30}', 1),
        (3, 'MACD Signal Cross', 'MACD line crosses above Signal line', 'MACD line crosses below Signal line', '{"fast":12,"slow":26,"signal":9}', 1)
    ]
    
    cursor.executemany("""
        INSERT INTO strategy (trader_id, strategy_name, entry_rule, exit_rule, indicator_params, is_active)
        VALUES (?, ?, ?, ?, ?, ?)
    """, strategies)
    print(f"  ✓ Inserted {len(strategies)} strategies")
    
    # Insert sample backtest reports
    backtests = [
        (1, 1, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 248, 58.47, 4250.00, 12.30, 1.82),
        (1, 2, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 210, 54.76, 2100.50, 15.20, 1.35),
        (2, 1, '2025-01-01 00:00:00', '2025-06-30 23:59:59', 142, 62.68, 3800.00, 9.50, 2.11)
    ]
    
    cursor.executemany("""
        INSERT INTO backtest_report (strategy_id, pair_id, start_date, end_date, total_trades, win_rate, total_profit_loss, max_drawdown, sharpe_ratio)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, backtests)
    print(f"  ✓ Inserted {len(backtests)} backtest reports")
    
    # Commit all changes
    conn.commit()
    
    # Verify database
    print("\n" + "="*60)
    print("✅ DATABASE SETUP COMPLETE!")
    print("="*60)
    
    # Show summary
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    tables = cursor.fetchall()
    print(f"\n📋 Tables created: {len(tables)}")
    for table in tables:
        cursor.execute(f"SELECT COUNT(*) FROM {table[0]}")
        count = cursor.fetchone()[0]
        print(f"  • {table[0]}: {count} records")
    
    # Show views
    cursor.execute("SELECT name FROM sqlite_master WHERE type='view' ORDER BY name")
    views = cursor.fetchall()
    if views:
        print(f"\n👁 Views created: {len(views)}")
        for view in views:
            print(f"  • {view[0]}")
    
    conn.close()
    return True

def test_database():
    """Test the database with sample queries"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("\n" + "="*60)
    print("DATABASE TEST QUERIES")
    print("="*60)
    
    # Test 1: Show active currency pairs
    print("\n1. Active Currency Pairs:")
    cursor.execute("SELECT pair_symbol, base_currency, quote_currency FROM currency_pair WHERE is_active=1 LIMIT 5")
    for row in cursor.fetchall():
        print(f"   {row[0]} ({row[1]}/{row[2]})")
    
    # Test 2: Show strategy leaderboard
    print("\n2. Top 3 Strategies by Profit:")
    cursor.execute("""
        SELECT strategy_name, total_profit_loss, win_rate 
        FROM vw_strategy_leaderboard 
        LIMIT 3
    """)
    for row in cursor.fetchall():
        print(f"   {row[0]}: ${row[1]:.2f} (Win Rate: {row[2]}%)")
    
    # Test 3: Show recent price bars
    print("\n3. Recent EUR/USD Price Bars:")
    cursor.execute("""
        SELECT open_time, open_price, high_price, low_price, close_price 
        FROM price_bar pb
        JOIN currency_pair cp ON cp.pair_id = pb.pair_id
        WHERE cp.pair_symbol = 'EUR/USD'
        ORDER BY open_time DESC LIMIT 3
    """)
    for row in cursor.fetchall():
        print(f"   {row[0]}: O:{row[1]} H:{row[2]} L:{row[3]} C:{row[4]}")
    
    conn.close()
    print("\n✅ All tests passed!")

if __name__ == "__main__":
    if setup_database():
        test_database()
    else:
        print("\n❌ Database setup failed!")
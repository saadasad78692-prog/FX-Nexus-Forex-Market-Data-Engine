-- =============================================================================
-- FX NEXUS: FOREX DATA ENGINE
-- SQLite Version - Converted from MySQL
-- =============================================================================

-- Enable foreign keys
PRAGMA foreign_keys = ON;

-- =============================================================================
-- TABLE 1: currency_pair
-- =============================================================================
CREATE TABLE currency_pair (
    pair_id         INTEGER     PRIMARY KEY AUTOINCREMENT,
    base_currency   TEXT(3)     NOT NULL,
    quote_currency  TEXT(3)     NOT NULL,
    pair_symbol     TEXT(10)    NOT NULL UNIQUE,
    pip_value       REAL        NOT NULL DEFAULT 0.00001,
    is_active       INTEGER     NOT NULL DEFAULT 1,
    created_at      TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (base_currency <> quote_currency),
    CHECK (pip_value > 0)
);

-- =============================================================================
-- TABLE 2: data_source
-- =============================================================================
CREATE TABLE data_source (
    source_id       INTEGER     PRIMARY KEY AUTOINCREMENT,
    source_name     TEXT(100)   NOT NULL UNIQUE,
    source_type     TEXT        NOT NULL CHECK(source_type IN ('API','PlatformExport','Dataset')),
    base_url        TEXT(255),
    api_key         TEXT(255),
    last_sync_time  TIMESTAMP,
    is_active       INTEGER     NOT NULL DEFAULT 1
);

-- =============================================================================
-- TABLE 3: trader (Supertype)
-- =============================================================================
CREATE TABLE trader (
    trader_id       INTEGER     PRIMARY KEY AUTOINCREMENT,
    full_name       TEXT(150)   NOT NULL,
    email           TEXT(255)   NOT NULL UNIQUE,
    password_hash   TEXT(255)   NOT NULL,
    trader_type     TEXT        NOT NULL CHECK(trader_type IN ('Analyst','Strategy')),
    created_at      TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- =============================================================================
-- TABLE 4: analyst_trader (Subtype)
-- =============================================================================
CREATE TABLE analyst_trader (
    trader_id               INTEGER     PRIMARY KEY,
    preferred_indicators    TEXT(255),
    query_history_limit     INTEGER     NOT NULL DEFAULT 1000,
    FOREIGN KEY (trader_id) REFERENCES trader(trader_id) ON DELETE CASCADE,
    CHECK (query_history_limit > 0)
);

-- =============================================================================
-- TABLE 5: strategy_trader (Subtype)
-- =============================================================================
CREATE TABLE strategy_trader (
    trader_id           INTEGER     PRIMARY KEY,
    risk_tolerance      TEXT        NOT NULL DEFAULT 'Medium' CHECK(risk_tolerance IN ('Low','Medium','High')),
    default_lot_size    REAL        NOT NULL DEFAULT 0.01,
    max_drawdown_pct    REAL,
    FOREIGN KEY (trader_id) REFERENCES trader(trader_id) ON DELETE CASCADE,
    CHECK (default_lot_size > 0),
    CHECK (max_drawdown_pct IS NULL OR (max_drawdown_pct BETWEEN 0 AND 100))
);

-- =============================================================================
-- TABLE 6: price_bar
-- =============================================================================
CREATE TABLE price_bar (
    bar_id      INTEGER     PRIMARY KEY AUTOINCREMENT,
    pair_id     INTEGER     NOT NULL,
    source_id   INTEGER     NOT NULL,
    timeframe   TEXT        NOT NULL CHECK(timeframe IN ('M1','M15','H1')),
    open_time   TIMESTAMP   NOT NULL,
    open_price  REAL        NOT NULL,
    high_price  REAL        NOT NULL,
    low_price   REAL        NOT NULL,
    close_price REAL        NOT NULL,
    volume      INTEGER     NOT NULL DEFAULT 0,
    FOREIGN KEY (pair_id)   REFERENCES currency_pair(pair_id) ON UPDATE CASCADE,
    FOREIGN KEY (source_id) REFERENCES data_source(source_id) ON UPDATE CASCADE,
    UNIQUE(pair_id, source_id, timeframe, open_time),
    CHECK (high_price >= open_price),
    CHECK (high_price >= close_price),
    CHECK (low_price <= open_price),
    CHECK (low_price <= close_price),
    CHECK (high_price >= low_price),
    CHECK (volume >= 0)
);

-- =============================================================================
-- TABLE 7: technical_indicator
-- =============================================================================
CREATE TABLE technical_indicator (
    indicator_id    INTEGER     PRIMARY KEY AUTOINCREMENT,
    bar_id          INTEGER     NOT NULL,
    indicator_type  TEXT        NOT NULL CHECK(indicator_type IN ('MA','RSI','MACD','BollingerBand','Stochastic','ATR')),
    period          INTEGER     NOT NULL,
    value1          REAL        NOT NULL,
    value2          REAL,
    value3          REAL,
    computed_at     TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bar_id) REFERENCES price_bar(bar_id) ON DELETE CASCADE,
    CHECK (period > 0),
    CHECK (indicator_type != 'RSI' OR (value1 BETWEEN 0 AND 100))
);

-- =============================================================================
-- TABLE 8: strategy
-- =============================================================================
CREATE TABLE strategy (
    strategy_id     INTEGER     PRIMARY KEY AUTOINCREMENT,
    trader_id       INTEGER     NOT NULL,
    strategy_name   TEXT(150)   NOT NULL,
    entry_rule      TEXT        NOT NULL,
    exit_rule       TEXT        NOT NULL,
    indicator_params TEXT,
    is_active       INTEGER     NOT NULL DEFAULT 1,
    created_at      TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (trader_id) REFERENCES strategy_trader(trader_id) ON UPDATE CASCADE
);

-- =============================================================================
-- TABLE 9: backtest_report
-- =============================================================================
CREATE TABLE backtest_report (
    report_id           INTEGER     PRIMARY KEY AUTOINCREMENT,
    strategy_id         INTEGER     NOT NULL,
    pair_id             INTEGER     NOT NULL,
    start_date          TIMESTAMP   NOT NULL,
    end_date            TIMESTAMP   NOT NULL,
    total_trades        INTEGER     NOT NULL DEFAULT 0,
    win_rate            REAL        NOT NULL DEFAULT 0.00,
    total_profit_loss   REAL        NOT NULL DEFAULT 0.00,
    max_drawdown        REAL        NOT NULL DEFAULT 0.00,
    sharpe_ratio        REAL,
    generated_at        TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (strategy_id) REFERENCES strategy(strategy_id) ON UPDATE CASCADE,
    FOREIGN KEY (pair_id) REFERENCES currency_pair(pair_id) ON UPDATE CASCADE,
    CHECK (end_date > start_date),
    CHECK (win_rate BETWEEN 0 AND 100),
    CHECK (max_drawdown BETWEEN 0 AND 100),
    CHECK (total_trades >= 0)
);

-- =============================================================================
-- TABLE 10: import_job
-- =============================================================================
CREATE TABLE import_job (
    job_id              INTEGER     PRIMARY KEY AUTOINCREMENT,
    trader_id           INTEGER     NOT NULL,
    source_id           INTEGER     NOT NULL,
    pair_id             INTEGER     NOT NULL,
    timeframe           TEXT        NOT NULL CHECK(timeframe IN ('M1','M15','H1')),
    status              TEXT        NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Running','Completed','Failed')),
    records_imported    INTEGER     NOT NULL DEFAULT 0,
    started_at          TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at        TIMESTAMP,
    error_message       TEXT,
    FOREIGN KEY (trader_id) REFERENCES trader(trader_id) ON UPDATE CASCADE,
    FOREIGN KEY (source_id) REFERENCES data_source(source_id) ON UPDATE CASCADE,
    FOREIGN KEY (pair_id) REFERENCES currency_pair(pair_id) ON UPDATE CASCADE,
    CHECK (records_imported >= 0)
);

-- =============================================================================
-- INDEXES
-- =============================================================================
CREATE INDEX idx_pb_pair_time ON price_bar (pair_id, timeframe, open_time);
CREATE INDEX idx_pb_source ON price_bar (source_id);
CREATE INDEX idx_pb_open_time ON price_bar (open_time);
CREATE INDEX idx_ti_bar ON technical_indicator (bar_id);
CREATE INDEX idx_ti_type_period ON technical_indicator (indicator_type, period);
CREATE INDEX idx_br_strategy ON backtest_report (strategy_id);
CREATE INDEX idx_br_pair_date ON backtest_report (pair_id, start_date, end_date);
CREATE INDEX idx_ij_trader_status ON import_job (trader_id, status);
CREATE INDEX idx_ij_pair_tf ON import_job (pair_id, timeframe);
CREATE INDEX idx_strategy_trader ON strategy (trader_id);

-- =============================================================================
-- VIEWS
-- =============================================================================

-- View 1: Active currency pairs with latest price bar summary
CREATE VIEW vw_pair_summary AS
SELECT
    cp.pair_id,
    cp.pair_symbol,
    cp.base_currency,
    cp.quote_currency,
    pb.timeframe,
    pb.open_time AS latest_bar_time,
    pb.close_price AS latest_close,
    pb.high_price  AS latest_high,
    pb.low_price   AS latest_low,
    pb.volume      AS latest_volume
FROM currency_pair cp
JOIN price_bar pb ON pb.pair_id = cp.pair_id
WHERE cp.is_active = 1
  AND pb.open_time = (
      SELECT MAX(pb2.open_time)
      FROM price_bar pb2
      WHERE pb2.pair_id = cp.pair_id AND pb2.timeframe = pb.timeframe
  );

-- View 2: Strategy performance leaderboard
CREATE VIEW vw_strategy_leaderboard AS
SELECT
    s.strategy_id,
    s.strategy_name,
    t.full_name         AS trader_name,
    cp.pair_symbol,
    br.total_trades,
    br.win_rate,
    br.total_profit_loss,
    br.max_drawdown,
    br.sharpe_ratio,
    br.generated_at
FROM backtest_report br
JOIN strategy s     ON s.strategy_id   = br.strategy_id
JOIN trader t       ON t.trader_id     = s.trader_id
JOIN currency_pair cp ON cp.pair_id   = br.pair_id
ORDER BY br.total_profit_loss DESC;

-- View 3: Import job status dashboard
CREATE VIEW vw_import_dashboard AS
SELECT
    ij.job_id,
    t.full_name         AS trader_name,
    ds.source_name,
    cp.pair_symbol,
    ij.timeframe,
    ij.status,
    ij.records_imported,
    ij.started_at,
    ij.completed_at,
    (strftime('%s', COALESCE(ij.completed_at, 'now')) - strftime('%s', ij.started_at)) AS duration_seconds
FROM import_job ij
JOIN trader t           ON t.trader_id   = ij.trader_id
JOIN data_source ds     ON ds.source_id  = ij.source_id
JOIN currency_pair cp   ON cp.pair_id    = ij.pair_id;
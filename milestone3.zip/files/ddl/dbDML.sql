-- =============================================================================
-- FX NEXUS: FOREX DATA ENGINE
-- DML Script — dbDML.sql
-- Course: CSC-271 Database Systems | Namal University, Mianwali
-- Student: SAAD Nawaz | Roll No: BSCS-2024-67
-- Version: 1.0 | Date: 21 June 2026
-- DBMS: MySQL 8.0+
-- NOTE: Run dbDDL.sql first to create the schema before running this script.
-- =============================================================================

USE fx_nexus;

-- =============================================================================
-- TABLE 1: currency_pair  (20 rows)
-- =============================================================================
INSERT INTO currency_pair (base_currency, quote_currency, pair_symbol, pip_value, is_active) VALUES
('EUR', 'USD', 'EUR/USD', 0.00010, TRUE),
('GBP', 'USD', 'GBP/USD', 0.00010, TRUE),
('USD', 'JPY', 'USD/JPY', 0.01000, TRUE),
('USD', 'CHF', 'USD/CHF', 0.00010, TRUE),
('AUD', 'USD', 'AUD/USD', 0.00010, TRUE),
('NZD', 'USD', 'NZD/USD', 0.00010, TRUE),
('USD', 'CAD', 'USD/CAD', 0.00010, TRUE),
('EUR', 'GBP', 'EUR/GBP', 0.00010, TRUE),
('EUR', 'JPY', 'EUR/JPY', 0.01000, TRUE),
('GBP', 'JPY', 'GBP/JPY', 0.01000, TRUE),
('AUD', 'JPY', 'AUD/JPY', 0.01000, TRUE),
('EUR', 'CHF', 'EUR/CHF', 0.00010, TRUE),
('GBP', 'CHF', 'GBP/CHF', 0.00010, TRUE),
('EUR', 'AUD', 'EUR/AUD', 0.00010, TRUE),
('EUR', 'CAD', 'EUR/CAD', 0.00010, TRUE),
('AUD', 'CAD', 'AUD/CAD', 0.00010, FALSE),
('NZD', 'JPY', 'NZD/JPY', 0.01000, FALSE),
('USD', 'SGD', 'USD/SGD', 0.00010, TRUE),
('USD', 'HKD', 'USD/HKD', 0.00010, FALSE),
('XAU', 'USD', 'XAU/USD', 0.01000, TRUE);

-- =============================================================================
-- TABLE 2: data_source  (20 rows)
-- =============================================================================
INSERT INTO data_source (source_name, source_type, base_url, api_key, last_sync_time) VALUES
('Yahoo Finance',        'API',            'https://query1.finance.yahoo.com/v8/finance', NULL,                     '2026-06-01 12:00:00'),
('OANDA API',            'API',            'https://api-fxtrade.oanda.com/v3',            'oanda-key-xxxx-1234',    '2026-06-10 08:00:00'),
('MetaTrader 5 Export',  'PlatformExport', NULL,                                          NULL,                     '2026-05-15 17:30:00'),
('MetaTrader 4 Export',  'PlatformExport', NULL,                                          NULL,                     '2026-04-20 09:00:00'),
('Kaggle EUR/USD 1H',    'Dataset',        'https://www.kaggle.com/datasets/eurusd',      NULL,                     '2026-01-05 00:00:00'),
('Alpha Vantage',        'API',            'https://www.alphavantage.co/query',           'av-key-yyyy-5678',       '2026-06-09 06:00:00'),
('Dukascopy Historical', 'Dataset',        'https://www.dukascopy.com/swiss/english/marketwatch/historical/', NULL, '2026-03-01 00:00:00'),
('Investing.com Export', 'Dataset',        NULL,                                          NULL,                     '2026-02-14 10:00:00'),
('Polygon.io API',       'API',            'https://api.polygon.io/v2/aggs',              'poly-key-zzzz-9012',     '2026-06-10 07:00:00'),
('TrueFX',              'API',            'https://www.truefx.com/api/data',             NULL,                     '2026-05-30 12:00:00'),
('Forex Factory Data',   'Dataset',        NULL,                                          NULL,                     '2026-01-01 00:00:00'),
('Quandl FOREX',         'API',            'https://data.nasdaq.com/api/v3',              'quandl-key-aaaa-3456',   '2026-04-01 00:00:00'),
('Interactive Brokers',  'API',            'https://api.ibkr.com/v1/api',                'ib-key-bbbb-7890',       '2026-06-08 09:00:00'),
('FXCM Historical',      'Dataset',        NULL,                                          NULL,                     '2025-12-01 00:00:00'),
('Histdata.com CSV',     'Dataset',        'https://www.histdata.com/download-free-forex-historical-data/', NULL, '2025-11-01 00:00:00'),
('LMAX Exchange',        'API',            'https://api.lmax.com/v1',                     'lmax-key-cccc-1122',     '2026-05-01 00:00:00'),
('Refinitiv Eikon',      'API',            'https://api.refinitiv.com/data/v1',           'ref-key-dddd-3344',      '2026-06-01 00:00:00'),
('Bloomberg Terminal',   'API',            'https://api.bloomberg.com/eap',               'bb-key-eeee-5566',       '2026-06-05 00:00:00'),
('MT5 Demo Export',      'PlatformExport', NULL,                                          NULL,                     '2026-05-20 12:00:00'),
('Custom CSV Import',    'Dataset',        NULL,                                          NULL,                     '2026-04-10 00:00:00');

-- =============================================================================
-- TABLE 3: trader — supertype  (20 rows: 10 Analyst, 10 Strategy)
-- =============================================================================
INSERT INTO trader (full_name, email, password_hash, trader_type) VALUES
('Saad Nawaz',         'saad.nawaz@namal.edu.pk',    '$2b$12$hash_saad_001',    'Strategy'),
('Ali Hassan',         'ali.hassan@namal.edu.pk',    '$2b$12$hash_ali_002',     'Analyst'),
('Fatima Malik',       'fatima.malik@namal.edu.pk',  '$2b$12$hash_fatima_003',  'Strategy'),
('Omar Farooq',        'omar.farooq@gmail.com',      '$2b$12$hash_omar_004',    'Analyst'),
('Zara Ahmed',         'zara.ahmed@gmail.com',       '$2b$12$hash_zara_005',    'Strategy'),
('Bilal Khan',         'bilal.khan@yahoo.com',       '$2b$12$hash_bilal_006',   'Analyst'),
('Hina Noor',          'hina.noor@gmail.com',        '$2b$12$hash_hina_007',    'Strategy'),
('Usman Iqbal',        'usman.iqbal@namal.edu.pk',   '$2b$12$hash_usman_008',   'Analyst'),
('Sana Raza',          'sana.raza@gmail.com',        '$2b$12$hash_sana_009',    'Strategy'),
('Kamran Shah',        'kamran.shah@gmail.com',      '$2b$12$hash_kamran_010',  'Analyst'),
('Aisha Tariq',        'aisha.tariq@namal.edu.pk',   '$2b$12$hash_aisha_011',   'Strategy'),
('Muneeb Aslam',       'muneeb.aslam@gmail.com',     '$2b$12$hash_muneeb_012',  'Analyst'),
('Rabia Qureshi',      'rabia.qureshi@hotmail.com',  '$2b$12$hash_rabia_013',   'Strategy'),
('Talha Butt',         'talha.butt@gmail.com',       '$2b$12$hash_talha_014',   'Analyst'),
('Nadia Hussain',      'nadia.hussain@namal.edu.pk', '$2b$12$hash_nadia_015',   'Strategy'),
('Faisal Mehmood',     'faisal.mehmood@gmail.com',   '$2b$12$hash_faisal_016',  'Analyst'),
('Amna Shahid',        'amna.shahid@gmail.com',      '$2b$12$hash_amna_017',    'Strategy'),
('Arslan Riaz',        'arslan.riaz@yahoo.com',      '$2b$12$hash_arslan_018',  'Analyst'),
('Sadia Pervez',       'sadia.pervez@gmail.com',     '$2b$12$hash_sadia_019',   'Strategy'),
('Hamza Javed',        'hamza.javed@namal.edu.pk',   '$2b$12$hash_hamza_020',   'Analyst');

-- =============================================================================
-- TABLE 4: analyst_trader — subtype  (10 rows, trader_ids 2,4,6,8,10,12,14,16,18,20)
-- =============================================================================
INSERT INTO analyst_trader (trader_id, preferred_indicators, query_history_limit) VALUES
(2,  'RSI,MA,MACD',          2000),
(4,  'BollingerBand,RSI',    1500),
(6,  'MA,Stochastic',        1000),
(8,  'MACD,ATR',             3000),
(10, 'RSI,ATR,MA',           2500),
(12, 'BollingerBand,MACD',   1000),
(14, 'Stochastic,RSI',       1200),
(16, 'MA',                   500),
(18, 'MACD,BollingerBand',   1800),
(20, 'RSI,MA,ATR',           2200);

-- =============================================================================
-- TABLE 5: strategy_trader — subtype  (10 rows, trader_ids 1,3,5,7,9,11,13,15,17,19)
-- =============================================================================
INSERT INTO strategy_trader (trader_id, risk_tolerance, default_lot_size, max_drawdown_pct) VALUES
(1,  'Medium', 0.10, 20.00),
(3,  'Low',    0.01, 10.00),
(5,  'High',   0.50, 35.00),
(7,  'Medium', 0.20, 25.00),
(9,  'Low',    0.05, 15.00),
(11, 'High',   1.00, 40.00),
(13, 'Medium', 0.10, 20.00),
(15, 'Low',    0.02, 12.00),
(17, 'High',   0.75, 30.00),
(19, 'Medium', 0.25, 22.00);

-- =============================================================================
-- TABLE 6: price_bar  (20 rows — EUR/USD H1 bars, pair_id=1, source_id=1)
-- =============================================================================
INSERT INTO price_bar (pair_id, source_id, timeframe, open_time, open_price, high_price, low_price, close_price, volume) VALUES
(1, 1, 'H1', '2026-06-01 00:00:00', 1.08450, 1.08710, 1.08320, 1.08600, 18452),
(1, 1, 'H1', '2026-06-01 01:00:00', 1.08600, 1.08750, 1.08500, 1.08680, 14320),
(1, 1, 'H1', '2026-06-01 02:00:00', 1.08680, 1.08820, 1.08610, 1.08790, 11250),
(1, 1, 'H1', '2026-06-01 03:00:00', 1.08790, 1.08900, 1.08650, 1.08710, 9870),
(1, 1, 'H1', '2026-06-01 04:00:00', 1.08710, 1.08760, 1.08480, 1.08520, 8210),
(1, 1, 'H1', '2026-06-01 05:00:00', 1.08520, 1.08610, 1.08350, 1.08430, 10540),
(1, 1, 'H1', '2026-06-01 06:00:00', 1.08430, 1.08900, 1.08400, 1.08850, 22310),
(1, 1, 'H1', '2026-06-01 07:00:00', 1.08850, 1.09100, 1.08780, 1.09020, 31450),
(1, 1, 'H1', '2026-06-01 08:00:00', 1.09020, 1.09350, 1.08950, 1.09280, 42300),
(1, 1, 'H1', '2026-06-01 09:00:00', 1.09280, 1.09500, 1.09100, 1.09180, 38900),
(1, 2, 'H1', '2026-06-01 10:00:00', 1.09180, 1.09250, 1.08900, 1.09010, 29870),
(1, 2, 'H1', '2026-06-01 11:00:00', 1.09010, 1.09080, 1.08750, 1.08820, 26540),
(1, 2, 'H1', '2026-06-01 12:00:00', 1.08820, 1.09100, 1.08700, 1.09050, 35200),
(1, 2, 'H1', '2026-06-01 13:00:00', 1.09050, 1.09300, 1.08980, 1.09210, 44100),
(2, 1, 'H1', '2026-06-01 08:00:00', 1.27350, 1.27800, 1.27200, 1.27650, 28500),
(2, 1, 'H1', '2026-06-01 09:00:00', 1.27650, 1.27950, 1.27500, 1.27880, 31200),
(3, 2, 'H1', '2026-06-01 08:00:00', 157.250, 158.100, 156.900, 157.820, 19800),
(3, 2, 'H1', '2026-06-01 09:00:00', 157.820, 158.450, 157.600, 158.300, 22400),
(5, 1, 'H1', '2026-06-01 08:00:00', 0.66120, 0.66450, 0.66000, 0.66330, 15600),
(20,1, 'H1', '2026-06-01 08:00:00', 2325.50, 2342.80, 2318.40, 2338.60, 9800);

-- =============================================================================
-- TABLE 7: technical_indicator  (20 rows)
-- =============================================================================
INSERT INTO technical_indicator (bar_id, indicator_type, period, value1, value2, value3, computed_at) VALUES
(1,  'MA',            14, 1.08512, NULL,    NULL,     '2026-06-01 00:01:00'),
(2,  'MA',            14, 1.08548, NULL,    NULL,     '2026-06-01 01:01:00'),
(3,  'MA',            14, 1.08591, NULL,    NULL,     '2026-06-01 02:01:00'),
(4,  'MA',            14, 1.08630, NULL,    NULL,     '2026-06-01 03:01:00'),
(5,  'MA',            14, 1.08650, NULL,    NULL,     '2026-06-01 04:01:00'),
(6,  'RSI',           14, 58.40,   NULL,    NULL,     '2026-06-01 05:01:00'),
(7,  'RSI',           14, 63.20,   NULL,    NULL,     '2026-06-01 06:01:00'),
(8,  'RSI',           14, 71.50,   NULL,    NULL,     '2026-06-01 07:01:00'),
(9,  'RSI',           14, 68.30,   NULL,    NULL,     '2026-06-01 08:01:00'),
(10, 'RSI',           14, 55.10,   NULL,    NULL,     '2026-06-01 09:01:00'),
(1,  'MACD',          12, 0.00045, 0.00038, 0.00007,  '2026-06-01 00:01:00'),
(2,  'MACD',          12, 0.00052, 0.00041, 0.00011,  '2026-06-01 01:01:00'),
(3,  'MACD',          12, 0.00061, 0.00046, 0.00015,  '2026-06-01 02:01:00'),
(4,  'MACD',          12, 0.00058, 0.00048, 0.00010,  '2026-06-01 03:01:00'),
(5,  'BollingerBand', 20, 1.08710, 1.09020, 1.08400,  '2026-06-01 04:01:00'),
(6,  'BollingerBand', 20, 1.08680, 1.09010, 1.08350,  '2026-06-01 05:01:00'),
(7,  'Stochastic',    14, 72.40,   65.30,   NULL,     '2026-06-01 06:01:00'),
(8,  'Stochastic',    14, 78.90,   71.20,   NULL,     '2026-06-01 07:01:00'),
(9,  'ATR',           14, 0.00285, NULL,    NULL,     '2026-06-01 08:01:00'),
(10, 'ATR',           14, 0.00312, NULL,    NULL,     '2026-06-01 09:01:00');

-- =============================================================================
-- TABLE 8: strategy  (20 rows)
-- =============================================================================
INSERT INTO strategy (trader_id, strategy_name, entry_rule, exit_rule, indicator_params, is_active) VALUES
(1,  'MA Crossover 20/50',        'MA(20) crosses above MA(50)',                     'MA(20) crosses below MA(50)',                  '{"fast":20,"slow":50}',           TRUE),
(1,  'RSI Reversal 30/70',        'RSI(14) drops below 30 (oversold)',               'RSI(14) rises above 70 (overbought)',           '{"period":14,"ob":70,"os":30}',   TRUE),
(3,  'MACD Signal Cross',         'MACD line crosses above Signal line',             'MACD line crosses below Signal line',          '{"fast":12,"slow":26,"signal":9}',TRUE),
(3,  'Bollinger Breakout',        'Close price breaks above upper Bollinger Band',   'Close price drops below middle band',          '{"period":20,"std":2}',           TRUE),
(5,  'Stochastic Divergence',     'Stochastic(14) %K crosses %D from below 20',     'Stochastic %K crosses %D from above 80',       '{"period":14}',                   TRUE),
(5,  'ATR Momentum',              'ATR(14) expands above 2x 20-period avg ATR',     'ATR(14) contracts below 1x avg ATR',           '{"period":14,"multiplier":2}',    TRUE),
(7,  'RSI Trend Filter MA',       'RSI>50 AND price above MA(200)',                  'RSI<50 OR price below MA(200)',                '{"rsi_period":14,"ma_period":200}',TRUE),
(7,  'Double EMA Scalper',        'EMA(5) > EMA(13) on M15',                        'EMA(5) < EMA(13) on M15',                     '{"fast":5,"slow":13}',            TRUE),
(9,  'Breakout Retest',           'Price breaks key resistance and retests it',      'Price fails to hold retest level',             '{}',                              TRUE),
(9,  'London Open Range',         'Buy at high of first 15min London candle +5pips', 'Target = 2x initial risk SL below range low', '{"session":"London"}',            FALSE),
(11, 'Golden Cross',              'MA(50) crosses above MA(200)',                    'MA(50) crosses below MA(200)',                 '{"fast":50,"slow":200}',          TRUE),
(11, 'Death Cross Short',         'MA(50) crosses below MA(200)',                    'Price rises back above MA(200)',               '{"fast":50,"slow":200}',          TRUE),
(13, 'RSI + MACD Confluence',     'RSI<30 AND MACD bullish cross',                  'RSI>60 OR MACD bearish cross',                 '{"rsi_period":14}',               TRUE),
(13, 'Mean Reversion H1',         'Price deviates >2 ATR from MA(50)',              'Price reverts to MA(50)',                      '{"atr_period":14,"ma_period":50}',TRUE),
(15, 'Trend Following EMA',       'Price > EMA(100) AND EMA(20) > EMA(50)',         'EMA(20) < EMA(50) OR price < EMA(100)',        '{"periods":[20,50,100]}',         TRUE),
(15, 'News Spike Fade',           'Spike candle >3x ATR — fade direction',          'Price retraces 50% of spike',                 '{"atr_mult":3}',                  FALSE),
(17, 'Asian Session Breakout',    'Trade breakout of Asian session range',           'End of NY session or 50% retracement',         '{"session":"Asian"}',             TRUE),
(17, 'Pivot Point Bounce',        'Price bounces off daily pivot support',          'Price reaches daily R1 resistance',            '{"type":"daily"}',                TRUE),
(19, 'Volume Price Trend',        'Volume spike + bullish engulfing candle',         'Volume contraction + bearish reversal candle', '{"vol_mult":2}',                  TRUE),
(19, 'Fibonacci Retracement',     'Price retraces to 61.8% Fibonacci level',        'Price reaches 0% or 100% Fibonacci level',    '{"levels":[0.382,0.618,0.786]}',  TRUE);

-- =============================================================================
-- TABLE 9: backtest_report  (20 rows)
-- =============================================================================
INSERT INTO backtest_report (strategy_id, pair_id, start_date, end_date, total_trades, win_rate, total_profit_loss, max_drawdown, sharpe_ratio) VALUES
(1,  1, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 248, 58.47, 4250.00,  12.30, 1.8200),
(1,  2, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 210, 54.76, 2100.50,  15.20, 1.3500),
(2,  1, '2025-01-01 00:00:00', '2025-06-30 23:59:59', 142, 62.68, 3800.00,   9.50, 2.1100),
(2,  3, '2025-01-01 00:00:00', '2025-06-30 23:59:59', 160, 51.25,  -450.75, 22.40, 0.6200),
(3,  1, '2024-06-01 00:00:00', '2025-05-31 23:59:59', 320, 49.69,  -820.00, 28.10, 0.4500),
(3,  2, '2024-06-01 00:00:00', '2025-05-31 23:59:59', 295, 55.25,  1750.25, 18.60, 1.1200),
(4,  1, '2025-03-01 00:00:00', '2025-12-31 23:59:59', 88,  70.45,  6300.00,   7.80, 2.8900),
(4,  5, '2025-03-01 00:00:00', '2025-12-31 23:59:59', 75,  65.33,  4100.50,  10.20, 2.2500),
(5,  3, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 412, 47.57, -1200.00, 31.50, 0.3100),
(5,  9, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 390, 52.31,   980.00,  24.70, 0.8800),
(7,  1, '2024-01-01 00:00:00', '2025-12-31 23:59:59', 520, 61.54,  8900.00,  11.20, 2.4400),
(7,  2, '2024-01-01 00:00:00', '2025-12-31 23:59:59', 480, 58.75,  6500.50,  13.40, 2.0100),
(8,  1, '2025-06-01 00:00:00', '2025-12-31 23:59:59', 680, 53.24,  2200.00,  16.80, 1.2800),
(9,  1, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 95,  68.42,  5100.75,   8.90, 2.6700),
(11, 1, '2020-01-01 00:00:00', '2025-12-31 23:59:59', 12,  75.00, 12500.00,   6.20, 3.5100),
(11, 2, '2020-01-01 00:00:00', '2025-12-31 23:59:59', 10,  70.00,  9800.25,   8.10, 3.1200),
(13, 1, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 180, 64.44,  5600.00,  10.50, 2.3400),
(15, 1, '2024-01-01 00:00:00', '2025-12-31 23:59:59', 290, 59.31,  7200.50,  12.80, 2.1800),
(17, 1, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 220, 56.82,  3100.00,  14.60, 1.6500),
(19, 2, '2025-01-01 00:00:00', '2025-12-31 23:59:59', 175, 61.71,  4800.25,  11.30, 2.0700);

-- =============================================================================
-- TABLE 10: import_job  (20 rows)
-- =============================================================================
INSERT INTO import_job (trader_id, source_id, pair_id, timeframe, status, records_imported, started_at, completed_at, error_message) VALUES
(1,  1,  1,  'H1',  'Completed', 8760,  '2026-01-01 08:00:00', '2026-01-01 08:12:30', NULL),
(1,  2,  2,  'H1',  'Completed', 8760,  '2026-01-01 09:00:00', '2026-01-01 09:10:45', NULL),
(3,  3,  1,  'M15', 'Completed', 35040, '2026-01-02 08:00:00', '2026-01-02 08:45:10', NULL),
(3,  4,  3,  'H1',  'Completed', 8760,  '2026-01-02 09:00:00', '2026-01-02 09:08:55', NULL),
(5,  1,  5,  'H1',  'Completed', 8760,  '2026-01-03 08:00:00', '2026-01-03 08:11:20', NULL),
(5,  5,  1,  'H1',  'Completed', 8760,  '2026-01-04 10:00:00', '2026-01-04 10:09:00', NULL),
(7,  2,  9,  'H1',  'Completed', 8760,  '2026-01-05 07:00:00', '2026-01-05 07:12:15', NULL),
(7,  6,  2,  'M15', 'Completed', 35040, '2026-01-06 08:00:00', '2026-01-06 09:02:40', NULL),
(9,  7,  1,  'M1',  'Completed', 525600,'2026-01-07 06:00:00', '2026-01-07 09:15:00', NULL),
(9,  1,  4,  'H1',  'Failed',    0,     '2026-01-08 08:00:00', '2026-01-08 08:01:10', 'API rate limit exceeded. Retry after 60s.'),
(11, 2,  1,  'H1',  'Completed', 8760,  '2026-02-01 08:00:00', '2026-02-01 08:10:00', NULL),
(11, 3,  8,  'H1',  'Completed', 4380,  '2026-02-02 09:00:00', '2026-02-02 09:06:30', NULL),
(13, 9,  2,  'H1',  'Completed', 8760,  '2026-03-01 08:00:00', '2026-03-01 08:11:45', NULL),
(13, 10, 3,  'M15', 'Completed', 35040, '2026-03-02 10:00:00', '2026-03-02 10:55:00', NULL),
(15, 1,  20, 'H1',  'Completed', 8760,  '2026-04-01 08:00:00', '2026-04-01 08:13:00', NULL),
(15, 2,  5,  'M1',  'Running',   128400,'2026-06-10 07:00:00', NULL,                  NULL),
(17, 5,  1,  'H1',  'Completed', 8760,  '2026-05-01 08:00:00', '2026-05-01 08:09:15', NULL),
(17, 7,  9,  'M15', 'Pending',   0,     '2026-06-10 08:00:00', NULL,                  NULL),
(19, 6,  2,  'H1',  'Completed', 8760,  '2026-05-15 08:00:00', '2026-05-15 08:10:30', NULL),
(19, 1,  3,  'H1',  'Failed',    1200,  '2026-06-09 20:00:00', '2026-06-09 20:05:00', 'Connection timeout. Partial import completed.');

-- =============================================================================
-- UPDATE STATEMENTS — demonstrate DML UPDATE operations
-- =============================================================================

-- Update pip value for XAU/USD (Gold)
UPDATE currency_pair
SET pip_value = 0.10000
WHERE pair_symbol = 'XAU/USD';

-- Deactivate a strategy that underperformed
UPDATE strategy
SET is_active = FALSE
WHERE strategy_name = 'Double EMA Scalper';

-- Update last sync time for Yahoo Finance after manual refresh
UPDATE data_source
SET last_sync_time = '2026-06-10 14:30:00'
WHERE source_name = 'Yahoo Finance';

-- Increase query history limit for power analyst
UPDATE analyst_trader
SET query_history_limit = 5000
WHERE trader_id = 2;

-- Update risk tolerance for a trader who changed preferences
UPDATE strategy_trader
SET risk_tolerance = 'Low', max_drawdown_pct = 8.00
WHERE trader_id = 5;

-- =============================================================================
-- DELETE STATEMENTS — demonstrate DML DELETE operations
-- =============================================================================

-- Remove a failed import job record after review
DELETE FROM import_job
WHERE status = 'Failed' AND error_message LIKE '%rate limit%';

-- Remove inactive currency pairs that have no price data
DELETE FROM currency_pair
WHERE is_active = FALSE
  AND pair_id NOT IN (SELECT DISTINCT pair_id FROM price_bar);

-- =============================================================================
-- END OF DML SCRIPT
-- =============================================================================

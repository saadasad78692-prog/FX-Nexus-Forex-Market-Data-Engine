-- =============================================================================
-- FX NEXUS: FOREX DATA ENGINE
-- DDL Script — dbDDL.sql
-- Course: CSC-271 Database Systems | Namal University, Mianwali
-- Student: SAAD Nawaz | Roll No: BSCS-2024-67
-- Version: 1.0 | Date: 21 June 2026
-- DBMS: MySQL 8.0+
-- =============================================================================

DROP DATABASE IF EXISTS fx_nexus;
CREATE DATABASE fx_nexus
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE fx_nexus;

-- =============================================================================
-- TABLE 1: currency_pair
-- Stores all Forex currency pairs tracked by the system.
-- =============================================================================
CREATE TABLE currency_pair (
    pair_id         INT             NOT NULL AUTO_INCREMENT,
    base_currency   CHAR(3)         NOT NULL,
    quote_currency  CHAR(3)         NOT NULL,
    pair_symbol     VARCHAR(10)     NOT NULL,
    pip_value       DECIMAL(10,5)   NOT NULL DEFAULT 0.00001,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_currency_pair     PRIMARY KEY (pair_id),
    CONSTRAINT uq_pair_symbol       UNIQUE (pair_symbol),
    CONSTRAINT chk_diff_currencies  CHECK (base_currency <> quote_currency),
    CONSTRAINT chk_pip_positive     CHECK (pip_value > 0)
);

-- =============================================================================
-- TABLE 2: data_source
-- Stores all external data providers used for importing price data.
-- =============================================================================
CREATE TABLE data_source (
    source_id       INT             NOT NULL AUTO_INCREMENT,
    source_name     VARCHAR(100)    NOT NULL,
    source_type     ENUM('API','PlatformExport','Dataset') NOT NULL,
    base_url        VARCHAR(255)    NULL,
    api_key         VARCHAR(255)    NULL,
    last_sync_time  DATETIME        NULL,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    CONSTRAINT pk_data_source       PRIMARY KEY (source_id),
    CONSTRAINT uq_source_name       UNIQUE (source_name)
);

-- =============================================================================
-- TABLE 3: trader  (Supertype)
-- Stores all system users — supertype for analyst_trader and strategy_trader.
-- =============================================================================
CREATE TABLE trader (
    trader_id       INT             NOT NULL AUTO_INCREMENT,
    full_name       VARCHAR(150)    NOT NULL,
    email           VARCHAR(255)    NOT NULL,
    password_hash   VARCHAR(255)    NOT NULL,
    trader_type     ENUM('Analyst','Strategy') NOT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_trader            PRIMARY KEY (trader_id),
    CONSTRAINT uq_trader_email      UNIQUE (email)
);

-- =============================================================================
-- TABLE 4: analyst_trader  (Subtype of Trader)
-- Additional attributes for traders focused on data analysis and indicators.
-- =============================================================================
CREATE TABLE analyst_trader (
    trader_id               INT             NOT NULL,
    preferred_indicators    VARCHAR(255)    NULL,
    query_history_limit     INT             NOT NULL DEFAULT 1000,
    CONSTRAINT pk_analyst_trader    PRIMARY KEY (trader_id),
    CONSTRAINT fk_analyst_trader    FOREIGN KEY (trader_id)
        REFERENCES trader(trader_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_query_limit      CHECK (query_history_limit > 0)
);

-- =============================================================================
-- TABLE 5: strategy_trader  (Subtype of Trader)
-- Additional attributes for traders who create and run backtesting strategies.
-- =============================================================================
CREATE TABLE strategy_trader (
    trader_id           INT             NOT NULL,
    risk_tolerance      ENUM('Low','Medium','High') NOT NULL DEFAULT 'Medium',
    default_lot_size    DECIMAL(5,2)    NOT NULL DEFAULT 0.01,
    max_drawdown_pct    DECIMAL(5,2)    NULL,
    CONSTRAINT pk_strategy_trader   PRIMARY KEY (trader_id),
    CONSTRAINT fk_strategy_trader   FOREIGN KEY (trader_id)
        REFERENCES trader(trader_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_lot_size         CHECK (default_lot_size > 0),
    CONSTRAINT chk_drawdown_pct     CHECK (max_drawdown_pct IS NULL OR max_drawdown_pct BETWEEN 0 AND 100)
);

-- =============================================================================
-- TABLE 6: price_bar
-- Core time-series table storing OHLCV candlestick data.
-- =============================================================================
CREATE TABLE price_bar (
    bar_id      BIGINT          NOT NULL AUTO_INCREMENT,
    pair_id     INT             NOT NULL,
    source_id   INT             NOT NULL,
    timeframe   ENUM('M1','M15','H1') NOT NULL,
    open_time   DATETIME        NOT NULL,
    open_price  DECIMAL(10,5)   NOT NULL,
    high_price  DECIMAL(10,5)   NOT NULL,
    low_price   DECIMAL(10,5)   NOT NULL,
    close_price DECIMAL(10,5)   NOT NULL,
    volume      BIGINT          NOT NULL DEFAULT 0,
    CONSTRAINT pk_price_bar         PRIMARY KEY (bar_id),
    CONSTRAINT fk_pb_pair           FOREIGN KEY (pair_id)
        REFERENCES currency_pair(pair_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_pb_source         FOREIGN KEY (source_id)
        REFERENCES data_source(source_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT uq_bar_composite     UNIQUE (pair_id, source_id, timeframe, open_time),
    CONSTRAINT chk_high_gte_open    CHECK (high_price >= open_price),
    CONSTRAINT chk_high_gte_close   CHECK (high_price >= close_price),
    CONSTRAINT chk_low_lte_open     CHECK (low_price  <= open_price),
    CONSTRAINT chk_low_lte_close    CHECK (low_price  <= close_price),
    CONSTRAINT chk_high_gte_low     CHECK (high_price >= low_price),
    CONSTRAINT chk_volume_positive  CHECK (volume >= 0)
);

-- =============================================================================
-- TABLE 7: technical_indicator
-- Stores computed indicator values (MA, RSI, MACD, etc.) linked to price bars.
-- =============================================================================
CREATE TABLE technical_indicator (
    indicator_id    BIGINT          NOT NULL AUTO_INCREMENT,
    bar_id          BIGINT          NOT NULL,
    indicator_type  ENUM('MA','RSI','MACD','BollingerBand','Stochastic','ATR') NOT NULL,
    period          INT             NOT NULL,
    value1          DECIMAL(15,6)   NOT NULL,
    value2          DECIMAL(15,6)   NULL,
    value3          DECIMAL(15,6)   NULL,
    computed_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_technical_indicator PRIMARY KEY (indicator_id),
    CONSTRAINT fk_ti_bar              FOREIGN KEY (bar_id)
        REFERENCES price_bar(bar_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_period_positive    CHECK (period > 0),
    CONSTRAINT chk_rsi_range          CHECK (
        indicator_type <> 'RSI' OR (value1 BETWEEN 0 AND 100)
    )
);

-- =============================================================================
-- TABLE 8: strategy
-- Defines a backtesting strategy created by a strategy_trader.
-- =============================================================================
CREATE TABLE strategy (
    strategy_id     INT             NOT NULL AUTO_INCREMENT,
    trader_id       INT             NOT NULL,
    strategy_name   VARCHAR(150)    NOT NULL,
    entry_rule      TEXT            NOT NULL,
    exit_rule       TEXT            NOT NULL,
    indicator_params JSON           NULL,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_strategy          PRIMARY KEY (strategy_id),
    CONSTRAINT fk_strategy_trader   FOREIGN KEY (trader_id)
        REFERENCES strategy_trader(trader_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

-- =============================================================================
-- TABLE 9: backtest_report
-- Records the outcome of executing a strategy over historical price data.
-- =============================================================================
CREATE TABLE backtest_report (
    report_id           INT             NOT NULL AUTO_INCREMENT,
    strategy_id         INT             NOT NULL,
    pair_id             INT             NOT NULL,
    start_date          DATETIME        NOT NULL,
    end_date            DATETIME        NOT NULL,
    total_trades        INT             NOT NULL DEFAULT 0,
    win_rate            DECIMAL(5,2)    NOT NULL DEFAULT 0.00,
    total_profit_loss   DECIMAL(15,2)   NOT NULL DEFAULT 0.00,
    max_drawdown        DECIMAL(5,2)    NOT NULL DEFAULT 0.00,
    sharpe_ratio        DECIMAL(8,4)    NULL,
    generated_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_backtest_report   PRIMARY KEY (report_id),
    CONSTRAINT fk_br_strategy       FOREIGN KEY (strategy_id)
        REFERENCES strategy(strategy_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_br_pair           FOREIGN KEY (pair_id)
        REFERENCES currency_pair(pair_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_date_range       CHECK (end_date > start_date),
    CONSTRAINT chk_win_rate_range   CHECK (win_rate BETWEEN 0 AND 100),
    CONSTRAINT chk_drawdown_range   CHECK (max_drawdown BETWEEN 0 AND 100),
    CONSTRAINT chk_trades_positive  CHECK (total_trades >= 0)
);

-- =============================================================================
-- TABLE 10: import_job
-- Represents a data ingestion job initiated by a trader.
-- =============================================================================
CREATE TABLE import_job (
    job_id              INT             NOT NULL AUTO_INCREMENT,
    trader_id           INT             NOT NULL,
    source_id           INT             NOT NULL,
    pair_id             INT             NOT NULL,
    timeframe           ENUM('M1','M15','H1') NOT NULL,
    status              ENUM('Pending','Running','Completed','Failed') NOT NULL DEFAULT 'Pending',
    records_imported    INT             NOT NULL DEFAULT 0,
    started_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at        DATETIME        NULL,
    error_message       TEXT            NULL,
    CONSTRAINT pk_import_job        PRIMARY KEY (job_id),
    CONSTRAINT fk_ij_trader         FOREIGN KEY (trader_id)
        REFERENCES trader(trader_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_ij_source         FOREIGN KEY (source_id)
        REFERENCES data_source(source_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_ij_pair           FOREIGN KEY (pair_id)
        REFERENCES currency_pair(pair_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_records_positive CHECK (records_imported >= 0)
);

-- =============================================================================
-- INDEXES — optimized for time-series and analytical queries
-- =============================================================================
CREATE INDEX idx_pb_pair_time       ON price_bar (pair_id, timeframe, open_time);
CREATE INDEX idx_pb_source          ON price_bar (source_id);
CREATE INDEX idx_pb_open_time       ON price_bar (open_time);
CREATE INDEX idx_ti_bar             ON technical_indicator (bar_id);
CREATE INDEX idx_ti_type_period     ON technical_indicator (indicator_type, period);
CREATE INDEX idx_br_strategy        ON backtest_report (strategy_id);
CREATE INDEX idx_br_pair_date       ON backtest_report (pair_id, start_date, end_date);
CREATE INDEX idx_ij_trader_status   ON import_job (trader_id, status);
CREATE INDEX idx_ij_pair_tf         ON import_job (pair_id, timeframe);
CREATE INDEX idx_strategy_trader    ON strategy (trader_id);

-- =============================================================================
-- VIEWS
-- =============================================================================

-- View 1: Active currency pairs with latest price bar summary
CREATE VIEW vw_pair_summary AS
SELECT
    cp.pair_id,
    cp.pair_symbol,
    cp.base_currency,
    cp.quote_currency,
    pb.timeframe,
    pb.open_time AS latest_bar_time,
    pb.close_price AS latest_close,
    pb.high_price  AS latest_high,
    pb.low_price   AS latest_low,
    pb.volume      AS latest_volume
FROM currency_pair cp
JOIN price_bar pb ON pb.pair_id = cp.pair_id
WHERE cp.is_active = TRUE
  AND pb.open_time = (
      SELECT MAX(pb2.open_time)
      FROM price_bar pb2
      WHERE pb2.pair_id = cp.pair_id AND pb2.timeframe = pb.timeframe
  );

-- View 2: Strategy performance leaderboard
CREATE VIEW vw_strategy_leaderboard AS
SELECT
    s.strategy_id,
    s.strategy_name,
    t.full_name         AS trader_name,
    cp.pair_symbol,
    br.total_trades,
    br.win_rate,
    br.total_profit_loss,
    br.max_drawdown,
    br.sharpe_ratio,
    br.generated_at
FROM backtest_report br
JOIN strategy s     ON s.strategy_id   = br.strategy_id
JOIN trader t       ON t.trader_id     = s.trader_id
JOIN currency_pair cp ON cp.pair_id   = br.pair_id
ORDER BY br.total_profit_loss DESC;

-- View 3: Import job status dashboard
CREATE VIEW vw_import_dashboard AS
SELECT
    ij.job_id,
    t.full_name         AS trader_name,
    ds.source_name,
    cp.pair_symbol,
    ij.timeframe,
    ij.status,
    ij.records_imported,
    ij.started_at,
    ij.completed_at,
    TIMESTAMPDIFF(SECOND, ij.started_at, IFNULL(ij.completed_at, NOW())) AS duration_seconds
FROM import_job ij
JOIN trader t           ON t.trader_id   = ij.trader_id
JOIN data_source ds     ON ds.source_id  = ij.source_id
JOIN currency_pair cp   ON cp.pair_id    = ij.pair_id;

-- =============================================================================
-- TRIGGERS
-- =============================================================================

DELIMITER $$

-- Trigger 1: Enforce exclusive specialization — Analyst cannot be a Strategy trader
CREATE TRIGGER trg_check_analyst_type
BEFORE INSERT ON analyst_trader
FOR EACH ROW
BEGIN
    DECLARE v_type ENUM('Analyst','Strategy');
    SELECT trader_type INTO v_type FROM trader WHERE trader_id = NEW.trader_id;
    IF v_type <> 'Analyst' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Trader type must be Analyst to insert into analyst_trader.';
    END IF;
END$$

-- Trigger 2: Enforce exclusive specialization — Strategy trader must have correct type
CREATE TRIGGER trg_check_strategy_type
BEFORE INSERT ON strategy_trader
FOR EACH ROW
BEGIN
    DECLARE v_type ENUM('Analyst','Strategy');
    SELECT trader_type INTO v_type FROM trader WHERE trader_id = NEW.trader_id;
    IF v_type <> 'Strategy' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Trader type must be Strategy to insert into strategy_trader.';
    END IF;
END$$

-- Trigger 3: Auto-set completed_at when import job status set to Completed or Failed
CREATE TRIGGER trg_import_job_complete
BEFORE UPDATE ON import_job
FOR EACH ROW
BEGIN
    IF NEW.status IN ('Completed','Failed') AND OLD.status = 'Running' THEN
        SET NEW.completed_at = CURRENT_TIMESTAMP;
    END IF;
END$$

-- Trigger 4: Update data_source last_sync_time when a new price_bar is inserted
CREATE TRIGGER trg_update_last_sync
AFTER INSERT ON price_bar
FOR EACH ROW
BEGIN
    UPDATE data_source
    SET last_sync_time = CURRENT_TIMESTAMP
    WHERE source_id = NEW.source_id;
END$$

DELIMITER ;

-- =============================================================================
-- STORED PROCEDURES
-- =============================================================================

DELIMITER $$

-- SP 1: Get all price bars for a pair and timeframe within a date range
CREATE PROCEDURE sp_get_price_bars(
    IN p_pair_symbol    VARCHAR(10),
    IN p_timeframe      ENUM('M1','M15','H1'),
    IN p_start_date     DATETIME,
    IN p_end_date       DATETIME
)
BEGIN
    SELECT pb.bar_id, cp.pair_symbol, pb.timeframe,
           pb.open_time, pb.open_price, pb.high_price,
           pb.low_price, pb.close_price, pb.volume,
           ds.source_name
    FROM price_bar pb
    JOIN currency_pair cp ON cp.pair_id   = pb.pair_id
    JOIN data_source   ds ON ds.source_id = pb.source_id
    WHERE cp.pair_symbol = p_pair_symbol
      AND pb.timeframe   = p_timeframe
      AND pb.open_time  BETWEEN p_start_date AND p_end_date
    ORDER BY pb.open_time ASC;
END$$

-- SP 2: Insert a new trader (with subtype)
CREATE PROCEDURE sp_insert_trader(
    IN p_full_name      VARCHAR(150),
    IN p_email          VARCHAR(255),
    IN p_password_hash  VARCHAR(255),
    IN p_trader_type    ENUM('Analyst','Strategy'),
    IN p_risk_tolerance ENUM('Low','Medium','High'),
    IN p_pref_indicators VARCHAR(255)
)
BEGIN
    DECLARE v_trader_id INT;
    INSERT INTO trader (full_name, email, password_hash, trader_type)
    VALUES (p_full_name, p_email, p_password_hash, p_trader_type);
    SET v_trader_id = LAST_INSERT_ID();

    IF p_trader_type = 'Analyst' THEN
        INSERT INTO analyst_trader (trader_id, preferred_indicators)
        VALUES (v_trader_id, p_pref_indicators);
    ELSE
        INSERT INTO strategy_trader (trader_id, risk_tolerance)
        VALUES (v_trader_id, p_risk_tolerance);
    END IF;

    SELECT v_trader_id AS new_trader_id;
END$$

-- SP 3: Get strategy performance summary
CREATE PROCEDURE sp_strategy_performance(
    IN p_trader_id INT
)
BEGIN
    SELECT s.strategy_name,
           cp.pair_symbol,
           br.total_trades,
           br.win_rate,
           br.total_profit_loss,
           br.max_drawdown,
           br.sharpe_ratio,
           br.generated_at
    FROM backtest_report br
    JOIN strategy      s  ON s.strategy_id = br.strategy_id
    JOIN currency_pair cp ON cp.pair_id    = br.pair_id
    WHERE s.trader_id = p_trader_id
    ORDER BY br.total_profit_loss DESC;
END$$

-- SP 4: Update import job status
CREATE PROCEDURE sp_update_import_status(
    IN p_job_id         INT,
    IN p_status         ENUM('Pending','Running','Completed','Failed'),
    IN p_records        INT,
    IN p_error_msg      TEXT
)
BEGIN
    UPDATE import_job
    SET status           = p_status,
        records_imported = IFNULL(p_records, records_imported),
        error_message    = p_error_msg
    WHERE job_id = p_job_id;
END$$

-- SP 5: Compute and insert simple Moving Average indicator
CREATE PROCEDURE sp_compute_ma(
    IN p_pair_id    INT,
    IN p_timeframe  ENUM('M1','M15','H1'),
    IN p_period     INT
)
BEGIN
    INSERT INTO technical_indicator (bar_id, indicator_type, period, value1)
    SELECT
        pb.bar_id,
        'MA',
        p_period,
        AVG(pb2.close_price)
    FROM price_bar pb
    JOIN price_bar pb2
        ON pb2.pair_id   = pb.pair_id
       AND pb2.timeframe = pb.timeframe
       AND pb2.open_time BETWEEN
           DATE_SUB(pb.open_time, INTERVAL p_period MINUTE) AND pb.open_time
    WHERE pb.pair_id   = p_pair_id
      AND pb.timeframe = p_timeframe
    GROUP BY pb.bar_id;
END$$

DELIMITER ;

-- =============================================================================
-- FUNCTIONS
-- =============================================================================

DELIMITER $$

-- Function 1: Calculate pip difference between two prices for a given pair
CREATE FUNCTION fn_pip_difference(
    p_pair_id       INT,
    p_price1        DECIMAL(10,5),
    p_price2        DECIMAL(10,5)
) RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE v_pip_value DECIMAL(10,5);
    SELECT pip_value INTO v_pip_value FROM currency_pair WHERE pair_id = p_pair_id;
    RETURN ROUND(ABS(p_price1 - p_price2) / v_pip_value, 2);
END$$

-- Function 2: Get total number of bars for a pair and timeframe
CREATE FUNCTION fn_bar_count(
    p_pair_id   INT,
    p_timeframe ENUM('M1','M15','H1')
) RETURNS INT
READS SQL DATA
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count
    FROM price_bar
    WHERE pair_id = p_pair_id AND timeframe = p_timeframe;
    RETURN v_count;
END$$

DELIMITER ;

-- =============================================================================
-- END OF DDL SCRIPT
-- =============================================================================

import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

class FXNexusGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("FX Nexus - Forex Data Engine")
        self.root.geometry("1300x800")
        
        # Database path
        self.db_path = Path(r'C:\Users\ASAD SAAD\Desktop\S4\DATABASE\project\milestone3\files\db\fx_nexus.db')
        
        self.setup_ui()
        self.load_data()
    
    def setup_ui(self):
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create tabs
        self.create_dashboard_tab()
        self.create_currency_pairs_tab()
        self.create_traders_tab()
        self.create_strategies_tab()
        self.create_price_data_tab()
        self.create_backtest_tab()
    
    def create_dashboard_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Dashboard")
        
        # Dashboard content
        frame = ttk.Frame(tab, padding="10")
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Summary cards
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Card 1: Total pairs
        cursor.execute("SELECT COUNT(*) FROM currency_pair WHERE is_active=1")
        active_pairs = cursor.fetchone()[0]
        
        card1 = ttk.LabelFrame(frame, text="Active Currency Pairs", padding="10")
        card1.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        ttk.Label(card1, text=str(active_pairs), font=('Arial', 24, 'bold')).pack()
        
        # Card 2: Total traders
        cursor.execute("SELECT COUNT(*) FROM trader")
        total_traders = cursor.fetchone()[0]
        
        card2 = ttk.LabelFrame(frame, text="Total Traders", padding="10")
        card2.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        ttk.Label(card2, text=str(total_traders), font=('Arial', 24, 'bold')).pack()
        
        # Card 3: Total strategies
        cursor.execute("SELECT COUNT(*) FROM strategy WHERE is_active=1")
        active_strategies = cursor.fetchone()[0]
        
        card3 = ttk.LabelFrame(frame, text="Active Strategies", padding="10")
        card3.grid(row=0, column=2, padx=10, pady=10, sticky="nsew")
        ttk.Label(card3, text=str(active_strategies), font=('Arial', 24, 'bold')).pack()
        
        # Performance leaderboard
        leaderboard_frame = ttk.LabelFrame(frame, text="Strategy Performance Leaderboard", padding="10")
        leaderboard_frame.grid(row=1, column=0, columnspan=3, padx=10, pady=10, sticky="nsew")
        
        tree = ttk.Treeview(leaderboard_frame, columns=('Strategy', 'Trader', 'Profit', 'Win Rate'), show='headings', height=8)
        tree.heading('Strategy', text='Strategy')
        tree.heading('Trader', text='Trader')
        tree.heading('Profit', text='Profit/Loss ($)')
        tree.heading('Win Rate', text='Win Rate (%)')
        
        tree.column('Strategy', width=200)
        tree.column('Trader', width=150)
        tree.column('Profit', width=120)
        tree.column('Win Rate', width=100)
        
        cursor.execute("""
            SELECT strategy_name, trader_name, total_profit_loss, win_rate 
            FROM vw_strategy_leaderboard 
            LIMIT 10
        """)
        
        for row in cursor.fetchall():
            tree.insert('', 'end', values=row)
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Import jobs status
        jobs_frame = ttk.LabelFrame(frame, text="Recent Import Jobs", padding="10")
        jobs_frame.grid(row=2, column=0, columnspan=3, padx=10, pady=10, sticky="nsew")
        
        jobs_tree = ttk.Treeview(jobs_frame, columns=('Job ID', 'Trader', 'Source', 'Pair', 'Status', 'Records'), show='headings', height=5)
        jobs_tree.heading('Job ID', text='Job ID')
        jobs_tree.heading('Trader', text='Trader')
        jobs_tree.heading('Source', text='Source')
        jobs_tree.heading('Pair', text='Pair')
        jobs_tree.heading('Status', text='Status')
        jobs_tree.heading('Records', text='Records')
        
        cursor.execute("SELECT * FROM vw_import_dashboard LIMIT 5")
        for row in cursor.fetchall():
            jobs_tree.insert('', 'end', values=row)
        
        jobs_tree.pack(fill=tk.BOTH, expand=True)
        
        conn.close()
        
        # Configure grid weights
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_columnconfigure(1, weight=1)
        frame.grid_columnconfigure(2, weight=1)
        frame.grid_rowconfigure(1, weight=1)
        frame.grid_rowconfigure(2, weight=1)
    
    def create_currency_pairs_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Currency Pairs")
        
        # Treeview for currency pairs
        tree_frame = ttk.Frame(tab, padding="10")
        tree_frame.pack(fill=tk.BOTH, expand=True)
        
        tree = ttk.Treeview(tree_frame, columns=('Symbol', 'Base', 'Quote', 'Pip Value', 'Active'), show='headings', height=20)
        tree.heading('Symbol', text='Pair Symbol')
        tree.heading('Base', text='Base Currency')
        tree.heading('Quote', text='Quote Currency')
        tree.heading('Pip Value', text='Pip Value')
        tree.heading('Active', text='Active')
        
        tree.column('Symbol', width=100)
        tree.column('Base', width=100)
        tree.column('Quote', width=100)
        tree.column('Pip Value', width=100)
        tree.column('Active', width=80)
        
        # Load data
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT pair_symbol, base_currency, quote_currency, pip_value, is_active FROM currency_pair")
        
        for row in cursor.fetchall():
            active = "Yes" if row[4] else "No"
            tree.insert('', 'end', values=(row[0], row[1], row[2], row[3], active))
        
        conn.close()
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def create_traders_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Traders")
        
        # Create notebook for trader subtypes
        trader_notebook = ttk.Notebook(tab)
        trader_notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # All traders tab
        all_tab = ttk.Frame(trader_notebook)
        trader_notebook.add(all_tab, text="All Traders")
        
        tree = ttk.Treeview(all_tab, columns=('Name', 'Email', 'Type', 'Created'), show='headings', height=20)
        tree.heading('Name', text='Full Name')
        tree.heading('Email', text='Email')
        tree.heading('Type', text='Trader Type')
        tree.heading('Created', text='Created At')
        
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT full_name, email, trader_type, created_at FROM trader")
        
        for row in cursor.fetchall():
            tree.insert('', 'end', values=row)
        
        conn.close()
        
        tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Analyst traders tab
        analyst_tab = ttk.Frame(trader_notebook)
        trader_notebook.add(analyst_tab, text="Analyst Traders")
        
        analyst_tree = ttk.Treeview(analyst_tab, columns=('Name', 'Preferred Indicators', 'Query Limit'), show='headings', height=20)
        analyst_tree.heading('Name', text='Trader Name')
        analyst_tree.heading('Preferred Indicators', text='Preferred Indicators')
        analyst_tree.heading('Query Limit', text='Query History Limit')
        
        cursor = self.get_connection().cursor()
        cursor.execute("""
            SELECT t.full_name, a.preferred_indicators, a.query_history_limit 
            FROM analyst_trader a
            JOIN trader t ON t.trader_id = a.trader_id
        """)
        
        for row in cursor.fetchall():
            analyst_tree.insert('', 'end', values=row)
        
        analyst_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Strategy traders tab
        strategy_tab = ttk.Frame(trader_notebook)
        trader_notebook.add(strategy_tab, text="Strategy Traders")
        
        strategy_tree = ttk.Treeview(strategy_tab, columns=('Name', 'Risk Tolerance', 'Lot Size', 'Max Drawdown'), show='headings', height=20)
        strategy_tree.heading('Name', text='Trader Name')
        strategy_tree.heading('Risk Tolerance', text='Risk Tolerance')
        strategy_tree.heading('Lot Size', text='Default Lot Size')
        strategy_tree.heading('Max Drawdown', text='Max Drawdown %')
        
        cursor = self.get_connection().cursor()
        cursor.execute("""
            SELECT t.full_name, s.risk_tolerance, s.default_lot_size, s.max_drawdown_pct 
            FROM strategy_trader s
            JOIN trader t ON t.trader_id = s.trader_id
        """)
        
        for row in cursor.fetchall():
            strategy_tree.insert('', 'end', values=row)
        
        strategy_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
    
    def create_strategies_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Trading Strategies")
        
        tree = ttk.Treeview(tab, columns=('Name', 'Trader', 'Entry Rule', 'Exit Rule', 'Active'), show='headings', height=20)
        tree.heading('Name', text='Strategy Name')
        tree.heading('Trader', text='Trader')
        tree.heading('Entry Rule', text='Entry Rule')
        tree.heading('Exit Rule', text='Exit Rule')
        tree.heading('Active', text='Active')
        
        tree.column('Name', width=150)
        tree.column('Trader', width=120)
        tree.column('Entry Rule', width=250)
        tree.column('Exit Rule', width=250)
        tree.column('Active', width=60)
        
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.strategy_name, t.full_name, s.entry_rule, s.exit_rule, 
                   CASE WHEN s.is_active = 1 THEN 'Yes' ELSE 'No' END
            FROM strategy s
            JOIN trader t ON t.trader_id = s.trader_id
        """)
        
        for row in cursor.fetchall():
            tree.insert('', 'end', values=row)
        
        conn.close()
        
        scrollbar = ttk.Scrollbar(tab, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def create_price_data_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Price Data")
        
        # Filter frame
        filter_frame = ttk.LabelFrame(tab, text="Filters", padding="10")
        filter_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(filter_frame, text="Currency Pair:").grid(row=0, column=0, padx=5)
        self.pair_var = tk.StringVar()
        pair_combo = ttk.Combobox(filter_frame, textvariable=self.pair_var, width=15)
        pair_combo.grid(row=0, column=1, padx=5)
        
        ttk.Label(filter_frame, text="Timeframe:").grid(row=0, column=2, padx=5)
        self.tf_var = tk.StringVar(value="H1")
        tf_combo = ttk.Combobox(filter_frame, textvariable=self.tf_var, values=['M1', 'M15', 'H1'], width=10)
        tf_combo.grid(row=0, column=3, padx=5)
        
        ttk.Label(filter_frame, text="Limit:").grid(row=0, column=4, padx=5)
        self.limit_var = tk.StringVar(value="100")
        limit_spin = ttk.Spinbox(filter_frame, from_=1, to=1000, textvariable=self.limit_var, width=10)
        limit_spin.grid(row=0, column=5, padx=5)
        
        ttk.Button(filter_frame, text="Refresh", command=lambda: self.load_price_data(tree)).grid(row=0, column=6, padx=10)
        
        # Load pair list
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT pair_symbol FROM currency_pair WHERE is_active=1")
        pairs = [row[0] for row in cursor.fetchall()]
        pair_combo['values'] = pairs
        if pairs:
            self.pair_var.set(pairs[0])
        conn.close()
        
        # Tree for price data
        tree_frame = ttk.Frame(tab)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        tree = ttk.Treeview(tree_frame, columns=('Time', 'Open', 'High', 'Low', 'Close', 'Volume'), show='headings', height=20)
        tree.heading('Time', text='Time')
        tree.heading('Open', text='Open')
        tree.heading('High', text='High')
        tree.heading('Low', text='Low')
        tree.heading('Close', text='Close')
        tree.heading('Volume', text='Volume')
        
        tree.column('Time', width=150)
        tree.column('Open', width=100)
        tree.column('High', width=100)
        tree.column('Low', width=100)
        tree.column('Close', width=100)
        tree.column('Volume', width=100)
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.load_price_data(tree)
    
    def load_price_data(self, tree):
        """Load price data based on filters"""
        # Clear existing data
        for item in tree.get_children():
            tree.delete(item)
        
        pair = self.pair_var.get()
        timeframe = self.tf_var.get()
        limit = int(self.limit_var.get())
        
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT pb.open_time, pb.open_price, pb.high_price, pb.low_price, pb.close_price, pb.volume
            FROM price_bar pb
            JOIN currency_pair cp ON cp.pair_id = pb.pair_id
            WHERE cp.pair_symbol = ? AND pb.timeframe = ?
            ORDER BY pb.open_time DESC
            LIMIT ?
        """, (pair, timeframe, limit))
        
        for row in cursor.fetchall():
            tree.insert('', 'end', values=row)
        
        conn.close()
    
    def create_backtest_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Backtest Reports")
        
        tree = ttk.Treeview(tab, columns=('Strategy', 'Pair', 'Trades', 'Win Rate', 'Profit', 'Drawdown', 'Sharpe'), show='headings', height=20)
        tree.heading('Strategy', text='Strategy')
        tree.heading('Pair', text='Currency Pair')
        tree.heading('Trades', text='Total Trades')
        tree.heading('Win Rate', text='Win Rate %')
        tree.heading('Profit', text='Profit/Loss')
        tree.heading('Drawdown', text='Max Drawdown %')
        tree.heading('Sharpe', text='Sharpe Ratio')
        
        tree.column('Strategy', width=150)
        tree.column('Pair', width=100)
        tree.column('Trades', width=80)
        tree.column('Win Rate', width=80)
        tree.column('Profit', width=100)
        tree.column('Drawdown', width=100)
        tree.column('Sharpe', width=80)
        
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.strategy_name, cp.pair_symbol, br.total_trades, br.win_rate, 
                   br.total_profit_loss, br.max_drawdown, br.sharpe_ratio
            FROM backtest_report br
            JOIN strategy s ON s.strategy_id = br.strategy_id
            JOIN currency_pair cp ON cp.pair_id = br.pair_id
            ORDER BY br.total_profit_loss DESC
        """)
        
        for row in cursor.fetchall():
            tree.insert('', 'end', values=row)
        
        conn.close()
        
        scrollbar = ttk.Scrollbar(tab, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    def load_data(self):
        """Load initial data"""
        pass

# Run the GUI
if __name__ == "__main__":
    root = tk.Tk()
    app = FXNexusGUI(root)
    root.mainloop()
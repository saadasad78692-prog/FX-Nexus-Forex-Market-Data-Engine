# FX Nexus: Forex Data Engine

A centralized relational database system for storing, analyzing, and backtesting Forex market data. Built as part of CSC-271 Database Systems coursework at Namal University, Mianwali.

---

## Purpose & Functionality

FX Nexus provides a unified platform that:
- Stores high-frequency OHLCV price data across multiple currency pairs and timeframes (M1, M15, H1)
- Tracks multiple external data sources (Yahoo Finance, OANDA, MetaTrader exports, etc.)
- Computes technical indicators (MA, RSI, MACD, Bollinger Bands, Stochastic, ATR)
- Enables traders to define, run, and evaluate backtesting strategies
- Manages data import jobs with full status tracking
- Provides a desktop GUI for all core database operations

---

## System Requirements

| Component     | Requirement                          |
|---------------|--------------------------------------|
| OS            | Windows 10/11, macOS 12+, Ubuntu 20+ |
| Python        | 3.9 or higher                        |
| MySQL         | 8.0 or higher                        |
| RAM           | Minimum 4 GB                         |
| Storage       | Minimum 500 MB free                  |
| Display       | 1280x800 or higher resolution        |

### Required Python Libraries
```
mysql-connector-python
tkinter (built-in with Python)
```

---

## Installation Instructions

### Step 1: Clone the Repository
```bash
git clone https://github.com/saadasad78692-prog/FX-Nexus-Forex-Market-Data-Engine.git
cd FX-Nexus-Forex-Market-Data-Engine
```

### Step 2: Install Python Dependencies
```bash
pip install mysql-connector-python
```

### Step 3: Set Up MySQL Database
Ensure MySQL 8.0+ is installed and running. Log in as root:
```bash
mysql -u root -p
```

### Step 4: Run DDL Script (Create Schema)
```bash
mysql -u root -p < dbDDL.sql
```

### Step 5: Run DML Script (Insert Sample Data)
```bash
mysql -u root -p < dbDML.sql
```

### Step 6: Configure Database Credentials
Open `fx_nexus_gui.py` and update the `DB_CONFIG` dictionary:
```python
DB_CONFIG = {
    'host':     'localhost',
    'port':     3306,
    'user':     'root',
    'password': 'your_actual_password',   # <-- update this
    'database': 'fx_nexus',
}
```

---

## Usage Instructions

### Launch the GUI
```bash
python fx_nexus_gui.py
```

### GUI Navigation

| Page            | Description                                           |
|-----------------|-------------------------------------------------------|
| Dashboard       | System statistics overview and strategy leaderboard   |
| Price Bars      | Retrieve OHLCV data using stored procedure            |
| Traders         | Add, view, and delete system users (traders)          |
| Currency Pairs  | Manage tracked currency pairs                         |
| Strategies      | View strategies and backtest performance              |
| Import Jobs     | Create and monitor data import jobs                   |
| Indicators      | Compute MAs and browse all indicator records          |

### All Operations Use Stored Procedures
All database write operations are routed through:
- `sp_get_price_bars()` — retrieve price bars by pair/timeframe/date
- `sp_insert_trader()` — insert trader with correct subtype
- `sp_strategy_performance()` — get backtest results for a trader
- `sp_update_import_status()` — update import job status
- `sp_compute_ma()` — compute Moving Average indicators

---

## Code Structure

```
FX-Nexus-Forex-Market-Data-Engine/
│
├── dbDDL.sql              # Full database schema (tables, indexes, views, triggers, SPs, functions)
├── dbDML.sql              # Sample data (20+ rows per table) + UPDATE/DELETE examples
├── fx_nexus_gui.py        # Main GUI application (Python + Tkinter)
├── README.md              # This file
│
└── docs/
    └── FX_Nexus_Milestone3_Report.docx    # Milestone 3 design report
    └── FX_Nexus_ERD.png                  # Entity Relationship Diagram
```

### Key Files

| File                | Description                                              |
|---------------------|----------------------------------------------------------|
| `dbDDL.sql`         | Creates all 10 tables, 10 indexes, 3 views, 4 triggers, 5 stored procedures, 2 functions |
| `dbDML.sql`         | Inserts 20 rows per table (200+ total rows); UPDATE and DELETE examples included |
| `fx_nexus_gui.py`   | Tkinter GUI with 7 pages; all writes via stored procedures |
| `README.md`         | Project documentation (this file)                        |

---

## Database Schema Overview

| Table                | Rows (Sample) | Description                         |
|----------------------|---------------|-------------------------------------|
| currency_pair        | 20            | Tracked Forex pairs                 |
| data_source          | 20            | External data providers             |
| trader               | 20            | All system users (supertype)        |
| analyst_trader       | 10            | Analyst subtype                     |
| strategy_trader      | 10            | Strategy trader subtype             |
| price_bar            | 20            | OHLCV candlestick data              |
| technical_indicator  | 20            | Computed indicators per bar         |
| strategy             | 20            | Backtesting strategy definitions    |
| backtest_report      | 20            | Backtest execution results          |
| import_job           | 20            | Data ingestion job tracking         |

---

## Student Information

| Field        | Details                          |
|--------------|----------------------------------|
| Name         | SAAD Nawaz                       |
| Roll No      | BSCS-2024-67                     |
| Section      | B                                |
| Course       | CSC-271 — Database Systems       |
| University   | Namal University, Mianwali       |
| Instructor   | Ma'am Asiya Batool               |
| Submission   | 21st June, 2026                  |

---

## References

1. Bank for International Settlements (BIS) — https://www.bis.org
2. Yahoo Finance API — https://www.yahoofinanceapi.com
3. OANDA API — https://www.oanda.com
4. TimescaleDB Documentation — https://docs.timescale.com
5. MySQL 8.0 Reference Manual — https://dev.mysql.com/doc/refman/8.0/en/
6. R. Elmasri & S. Navathe, *Fundamentals of Database Systems*, 7th Ed., Pearson, 2016.

---

## AI Tools Used

- **Claude (Anthropic)** — claude.ai — Used to generate SQL schema, stored procedures, triggers, DML data, GUI code, and report content for Milestone 3.
- **ChatGPT (OpenAI)** — Used in Milestone 1 for initial proposal drafting.
- **Gemini AI (Google)** — Used in Milestone 1 for database design guidance.
